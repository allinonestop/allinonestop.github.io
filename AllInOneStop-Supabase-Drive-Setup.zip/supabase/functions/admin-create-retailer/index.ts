import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const adminClient = createClient(supabaseUrl, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

function retailerEmail(username: string) {
  return `${String(username).trim().toLowerCase()}@retailer.allinonestop.local`;
}

async function requireAdmin(req: Request) {
  const auth = req.headers.get("Authorization");
  if (!auth) throw new Error("Missing authorization.");

  const token = auth.replace(/^Bearer\s+/i, "");
  const { data: userData, error: userError } =
    await adminClient.auth.getUser(token);

  if (userError || !userData.user) throw new Error("Invalid or expired session.");

  const { data: profile, error: profileError } = await adminClient
    .from("profiles")
    .select("id,role,full_name")
    .eq("id", userData.user.id)
    .maybeSingle();

  if (profileError) throw new Error(profileError.message);
  if (!profile || profile.role !== "admin") throw new Error("Admin access required.");

  return userData.user;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const adminUser = await requireAdmin(req);
    const body = await req.json();
    const action = String(body.action || "").trim();

    if (action === "create") {
      const fullName = String(body.full_name || "").trim();
      const mobile = String(body.mobile || "").trim();
      const username = String(body.username || "").trim().toUpperCase();
      const retailerNumber = String(body.retailer_number || username).trim();
      const password = String(body.password || "");

      if (!fullName) throw new Error("Retailer full name is required.");
      if (!/^\d{10}$/.test(mobile)) throw new Error("Mobile number must be exactly 10 digits.");
      if (!/^RET-[A-Z0-9]{4,20}$/i.test(username)) throw new Error("Invalid retailer ID.");
      if (password.length < 6) throw new Error("Password must be at least 6 characters.");

      const email = retailerEmail(username);

      const { data: existingProfile } = await adminClient
        .from("profiles")
        .select("id")
        .eq("retailer_number", retailerNumber)
        .maybeSingle();

      if (existingProfile) throw new Error("Retailer ID/number already exists.");

      const { data: created, error: createError } =
        await adminClient.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            full_name: fullName,
            retailer_number: retailerNumber,
          },
        });

      if (createError || !created.user) {
        throw new Error(createError?.message || "Could not create retailer Auth user.");
      }

      const { error: profileError } = await adminClient
        .from("profiles")
        .insert({
          id: created.user.id,
          full_name: fullName,
          role: "retailer",
          retailer_number: retailerNumber,
          mobile,
        });

      if (profileError) {
        await adminClient.auth.admin.deleteUser(created.user.id);
        throw new Error(profileError.message);
      }

      return json({
        success: true,
        username,
        retailer_number: retailerNumber,
        user_id: created.user.id,
        created_by: adminUser.id,
      });
    }

    if (action === "reset_password") {
      const userId = String(body.user_id || "").trim();
      const password = String(body.password || "");
      if (!userId || password.length < 6) throw new Error("Valid user ID and password (6+ chars) are required.");

      const { error } = await adminClient.auth.admin.updateUserById(userId, { password });
      if (error) throw new Error(error.message);
      return json({ success: true });
    }

    if (action === "delete") {
      const userId = String(body.user_id || "").trim();
      if (!userId || userId === adminUser.id) throw new Error("Invalid user ID.");

      const { error } = await adminClient.auth.admin.deleteUser(userId);
      if (error) throw new Error(error.message);

      return json({ success: true });
    }

    throw new Error("Unknown action.");
  } catch (error) {
    return json({ success: false, error: error instanceof Error ? error.message : String(error) }, 400);
  }
});
