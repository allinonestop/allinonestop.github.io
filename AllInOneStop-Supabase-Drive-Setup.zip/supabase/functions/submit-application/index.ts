import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const driveWebAppUrl = Deno.env.get("GOOGLE_DRIVE_WEBAPP_URL")!;
const driveToken = Deno.env.get("GOOGLE_DRIVE_TOKEN")!;

const db = createClient(supabaseUrl, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

function makeTr() {
  const d = new Date();
  const ymd = d.toISOString().slice(0, 10).replaceAll("-", "");
  const rnd = Math.floor(100000 + Math.random() * 900000);
  const rnd2 = Math.floor(100000 + Math.random() * 900000);
  return `TR-${ymd}-${rnd}-${rnd2}`;
}

function safeString(v: unknown) {
  return String(v ?? "").trim();
}

function maskMobile(mobile: string) {
  return mobile && mobile.length === 10 ? `${mobile.slice(0, 2)}******${mobile.slice(-2)}` : mobile;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    if (!auth) throw new Error("Login required.");

    const token = auth.replace(/^Bearer\s+/i, "");
    const { data: userData, error: userError } = await db.auth.getUser(token);
    if (userError || !userData.user) throw new Error("Invalid or expired login session.");

    const { data: retailer, error: retailerError } = await db
      .from("profiles")
      .select("id,full_name,mobile,retailer_number,role")
      .eq("id", userData.user.id)
      .maybeSingle();

    if (retailerError) throw new Error(retailerError.message);
    if (!retailer || retailer.role !== "retailer") throw new Error("Retailer account required.");

    const body = await req.json();

    const serviceId = safeString(body.service_id);
    const customerMobile = safeString(body.customer_mobile);
    const customerEmail = safeString(body.customer_email);
    const utrNumber = safeString(body.utr_number);
    const fields = body.fields && typeof body.fields === "object" ? body.fields : {};
    const files = body.files && typeof body.files === "object" ? body.files : {};

    if (!serviceId) throw new Error("Service is required.");
    if (!/^\d{10}$/.test(customerMobile)) throw new Error("Customer mobile must be exactly 10 digits.");
    if (!utrNumber) throw new Error("UTR / transaction number is required.");

    const { data: service, error: serviceError } = await db
      .from("services")
      .select("id,name,amount,without_ration_amount,fields,active")
      .eq("id", serviceId)
      .eq("active", true)
      .maybeSingle();

    if (serviceError) throw new Error(serviceError.message);
    if (!service) throw new Error("Selected service is not available.");

    const withoutRation = fields.without_ration_card === true;
    const amount = Number(withoutRation && service.without_ration_amount != null
      ? service.without_ration_amount
      : service.amount);

    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Invalid service amount.");

    const allowedFields = Array.isArray(service.fields) ? service.fields.map(String) : [];
    const cleanFields: Record<string, unknown> = {};
    for (const key of allowedFields) {
      if (Object.prototype.hasOwnProperty.call(fields, key)) cleanFields[key] = fields[key];
    }
    cleanFields.without_ration_card = withoutRation;

    const fileEntries: Record<string, {name:string;type:string;data:string}> = {};
    for (const [field, value] of Object.entries(files)) {
      if (!allowedFields.includes(field)) continue;
      const f = value as any;
      if (!f || typeof f.data !== "string" || typeof f.name !== "string") continue;
      if (f.data.length > 15_000_000) throw new Error(`Document ${field} is too large.`);
      fileEntries[field] = {
        name: f.name.slice(0, 180),
        type: safeString(f.type) || "application/octet-stream",
        data: f.data,
      };
    }

    const trNumber = makeTr();

    const { data: application, error: insertError } = await db
      .from("applications")
      .insert({
        tr_number: trNumber,
        retailer_id: retailer.id,
        service_id: service.id,
        service_name: service.name,
        customer_name_en: safeString(fields.name_english) || "Applicant",
        customer_name_gu: safeString(fields.name_gujarati) || null,
        customer_email: customerEmail || null,
        dob: safeString(fields.dob) || null,
        mobile: customerMobile,
        amount,
        utr_number: utrNumber,
        payment_status: "Pending",
        application_status: "Received",
        details: {
          ...cleanFields,
          retailer_name: retailer.full_name,
          retailer_number: retailer.retailer_number,
          retailer_mobile: retailer.mobile,
          customer_mobile_masked: maskMobile(customerMobile),
        },
        documents: {},
        documents_status: Object.keys(fileEntries).length ? "Failed" : "Not Required",
      })
      .select("id,tr_number")
      .single();

    if (insertError || !application) throw new Error(insertError?.message || "Could not create application.");

    let driveFolderUrl = "";
    let documents: Record<string, unknown> = {};

    if (Object.keys(fileEntries).length) {
      if (!driveWebAppUrl || !driveToken) {
        await db.from("applications").update({
          documents_status: "Failed",
          remark: "Google Drive backend is not configured."
        }).eq("id", application.id);
        throw new Error("Google Drive backend is not configured.");
      }

      const driveResponse = await fetch(driveWebAppUrl, {
        method: "POST",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({
          token: driveToken,
          action: "upload_documents",
          trNumber,
          retailerNumber: retailer.retailer_number,
          applicantName: safeString(fields.name_english) || "Applicant",
          files: fileEntries,
        }),
      });

      const driveData = await driveResponse.json().catch(() => null);
      if (!driveResponse.ok || !driveData?.success) {
        const msg = driveData?.message || `Drive upload failed (${driveResponse.status}).`;
        await db.from("applications").update({
          documents_status: "Failed",
          remark: msg
        }).eq("id", application.id);
        throw new Error(msg);
      }

      driveFolderUrl = String(driveData.folderUrl || "");
      documents = driveData.documents || {};

      await db.from("applications").update({
        drive_folder_url: driveFolderUrl || null,
        documents,
        documents_status: "Uploaded",
        remark: null,
      }).eq("id", application.id);
    } else {
      await db.from("applications").update({
        documents_status: "Not Required"
      }).eq("id", application.id);
    }

    return json({
      success: true,
      trNumber,
      applicationId: application.id,
      driveFolder: driveFolderUrl,
      documents,
      applicationStatus: "Received",
      paymentStatus: "Pending",
    });
  } catch (error) {
    return json({ success: false, message: error instanceof Error ? error.message : String(error) }, 400);
  }
});
