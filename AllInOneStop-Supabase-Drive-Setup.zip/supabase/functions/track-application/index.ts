import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const db = createClient(supabaseUrl, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

function maskMobile(mobile: string) {
  const m = String(mobile || "");
  return /^\d{10}$/.test(m) ? `${m.slice(0, 2)}******${m.slice(-2)}` : "-";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const url = new URL(req.url);
    const trNumber = String(
      url.searchParams.get("trNumber") ||
      url.searchParams.get("tr_number") ||
      ""
    ).trim().toUpperCase();

    if (!trNumber) throw new Error("TR Number required.");

    const { data, error } = await db
      .from("applications")
      .select(`
        tr_number,
        service_name,
        customer_name_en,
        mobile,
        amount,
        utr_number,
        payment_status,
        application_status,
        created_at,
        drive_folder_url
      `)
      .eq("tr_number", trNumber)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) return json({ success: false, message: "Application not found." }, 404);

    return json({
      success: true,
      trNumber: data.tr_number,
      applicationStatus: data.application_status,
      paymentStatus: data.payment_status,
      serviceName: data.service_name,
      applicantName: data.customer_name_en,
      customerMobile: maskMobile(data.mobile),
      amount: data.amount,
      utrNumber: data.utr_number || "-",
      createdAt: data.created_at,
      driveFolder: data.drive_folder_url || "",
    });
  } catch (error) {
    return json({
      success: false,
      message: error instanceof Error ? error.message : String(error)
    }, 400);
  }
});
