-- Add your ACTUAL service list here.
-- The previous uploaded files did not contain the service master data,
-- so do not use these examples as real prices.

insert into public.services (id,name,amount,without_ration_amount,fields)
values
('SERVICE_ID_1','YOUR SERVICE NAME',0,null,'[]'::jsonb);

-- Example document fields:
-- ["ration_pdf","aadhaar_pdf","photo","signature","lc_pdf"]
