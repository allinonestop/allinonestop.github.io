-- AllInOneStop: Supabase database
-- DATA: Supabase stores ALL application/retailer/service/payment data.
-- FILES: Google Drive stores ONLY uploaded document files.
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('admin','retailer')),
  retailer_number text unique,
  mobile text,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id text primary key,
  name text not null,
  amount numeric(10,2) not null default 0,
  without_ration_amount numeric(10,2),
  fields jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  tr_number text not null unique,
  retailer_id uuid not null references public.profiles(id),
  service_id text references public.services(id),
  service_name text not null,
  customer_name_en text not null,
  customer_name_gu text,
  customer_email text,
  dob date,
  mobile text,
  amount numeric(10,2) not null default 0,
  utr_number text,
  payment_status text not null default 'Pending'
    check (payment_status in ('Pending','Paid','Failed')),
  application_status text not null default 'Received'
    check (application_status in ('Received','Verification','Processing','Completed','Rejected')),
  remark text,
  details jsonb not null default '{}'::jsonb,
  documents jsonb not null default '{}'::jsonb,
  drive_folder_url text,
  documents_status text not null default 'Not Required'
    check (documents_status in ('Not Required','Uploaded','Failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists applications_tr_idx on public.applications(tr_number);
create index if not exists applications_retailer_idx on public.applications(retailer_id);
create index if not exists applications_created_idx on public.applications(created_at desc);
create index if not exists services_active_idx on public.services(active);

-- Safe upgrades for an older database.
alter table public.applications add column if not exists service_id text;
alter table public.applications add column if not exists customer_email text;
alter table public.applications add column if not exists utr_number text;
alter table public.applications add column if not exists details jsonb not null default '{}'::jsonb;
alter table public.applications add column if not exists documents jsonb not null default '{}'::jsonb;
alter table public.applications add column if not exists drive_folder_url text;
alter table public.applications add column if not exists documents_status text not null default 'Not Required';

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
drop trigger if exists services_updated_at on public.services;
drop trigger if exists applications_updated_at on public.applications;

create trigger services_updated_at
before update on public.services
for each row execute function public.set_updated_at();

create trigger applications_updated_at
before update on public.applications
for each row execute function public.set_updated_at();

create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.is_retailer()
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'retailer'
  );
$$;

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.applications enable row level security;

-- Profiles
drop policy if exists "admin profiles" on public.profiles;
create policy "admin profiles"
on public.profiles for all to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "retailer own profile" on public.profiles;
create policy "retailer own profile"
on public.profiles for select to authenticated
using (id = auth.uid());

-- Services are readable by logged-in retailers/admins.
drop policy if exists "authenticated read active services" on public.services;
create policy "authenticated read active services"
on public.services for select to authenticated
using (active = true or public.is_admin());

drop policy if exists "admin manage services" on public.services;
create policy "admin manage services"
on public.services for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Applications: inserts/updates are controlled.
drop policy if exists "retailer create applications" on public.applications;
create policy "retailer create applications"
on public.applications for insert to authenticated
with check (public.is_retailer() and retailer_id = auth.uid());

drop policy if exists "retailer read own applications" on public.applications;
create policy "retailer read own applications"
on public.applications for select to authenticated
using (public.is_admin() or retailer_id = auth.uid());

drop policy if exists "admin update applications" on public.applications;
create policy "admin update applications"
on public.applications for update to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Public tracking is intentionally limited to application rows.
-- The tracking page should only display masked customer mobile.
-- No Supabase Storage bucket is needed for documents.
-- Documents are kept in Google Drive only.
-- Do NOT create a public Supabase storage bucket for documents.

-- First admin:
-- 1) Create email/password user in Supabase Auth.
-- 2) Copy the Auth user's UUID.
-- 3) Run:
-- insert into public.profiles(id, full_name, role)
-- values ('YOUR_AUTH_USER_UUID', 'Admin', 'admin');

-- Example service format:
-- insert into public.services(id,name,amount,without_ration_amount,fields)
-- values
-- ('SERVICE_ID','Service Name',100,150,
--  '["ration_pdf","aadhaar_pdf","photo","signature"]'::jsonb);
