/**
 * AllInOneStop Google Drive document backend
 *
 * IMPORTANT:
 * - This script stores ONLY uploaded document files in Google Drive.
 * - Application/customer/payment data stays in Supabase.
 * - Set DRIVE_ROOT_FOLDER_ID and DRIVE_UPLOAD_TOKEN in Script Properties.
 *
 * Deploy:
 *   Deploy -> New deployment -> Web app
 *   Execute as: Me
 *   Who has access: Anyone
 *
 * The URL of this deployment goes into the Supabase Edge Function secret:
 * GOOGLE_DRIVE_WEBAPP_URL
 *
 * The same random token goes into:
 * - Script Property DRIVE_UPLOAD_TOKEN
 * - Supabase secret GOOGLE_DRIVE_TOKEN
 */

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || "{}");
    const props = PropertiesService.getScriptProperties();

    const expectedToken = props.getProperty("DRIVE_UPLOAD_TOKEN") || "";
    if (!expectedToken || body.token !== expectedToken) {
      return output({ success: false, message: "Unauthorized." }, 401);
    }

    if (body.action !== "upload_documents") {
      return output({ success: false, message: "Unknown action." }, 400);
    }

    const rootId = props.getProperty("DRIVE_ROOT_FOLDER_ID") || "";
    if (!rootId) {
      return output({ success: false, message: "DRIVE_ROOT_FOLDER_ID is not configured." }, 500);
    }

    const root = DriveApp.getFolderById(rootId);
    const trNumber = sanitize(body.trNumber || "TR");
    const retailerNumber = sanitize(body.retailerNumber || "Retailer");
    const applicantName = sanitize(body.applicantName || "Applicant");

    const folderName = `${trNumber} - ${applicantName}`;
    const folder = root.createFolder(folderName);

    const files = body.files || {};
    const result = {};

    Object.keys(files).forEach(function(field) {
      const item = files[field] || {};
      if (!item.data || !item.name) return;

      const base64 = String(item.data).split(",").pop();
      const bytes = Utilities.base64Decode(base64);
      const safeName = sanitizeFileName(item.name);
      const finalName = `${field} - ${safeName}`;
      const blob = Utilities.newBlob(bytes, item.type || MimeType.BINARY, finalName);
      const file = folder.createFile(blob);

      result[field] = {
        fileId: file.getId(),
        name: file.getName(),
        url: file.getUrl(),
        size: bytes.length
      };
    });

    return output({
      success: true,
      folderId: folder.getId(),
      folderUrl: folder.getUrl(),
      folderName: folder.getName(),
      retailerNumber: retailerNumber,
      trNumber: trNumber,
      documents: result
    }, 200);
  } catch (err) {
    return output({
      success: false,
      message: err && err.message ? err.message : String(err)
    }, 500);
  }
}

function sanitize(value) {
  return String(value)
    .replace(/[\\/:*?"<>|#%{}]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function sanitizeFileName(value) {
  return String(value)
    .replace(/[\\/:*?"<>|#%{}]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 150);
}

function output(obj, statusCode) {
  // Apps Script ContentService does not let us set an arbitrary HTTP status.
  // The JSON success flag is the authoritative result.
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
